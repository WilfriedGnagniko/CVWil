#ifndef CONVEX_H_
#define CONVEX_H_

void launchConvexHull(const char *infilename, const char *outfilname, const int algo, const int sort);

#endif
