Pojet de synthèse de FIORELLI Enzo et GNAGNIKO Wilfried

La branche principale est la branche master, la branche main était une erreur mais nous la gardons par sécurité.
Nous avons rajouté un fichier test.c où nous avons fait tout les tests pour ne pas polluer le main.
Les fichiers testInD1 et testOutD1 nous servent de test pour ne pas affecter les autres fichiers du dossier data.

url du gitlab : https://gitlab.univ-lorraine.fr/fiorelli4u/projet_synthese.git

Normalement je vous ai mis en maintainer afin que vous puissiez accéder au code. 


Merci de votre compréhension