#ifndef _TEST_H_
#define _TEST_H_

void finalListTest();

int finalTreeTest();

void finalSortTest();

void finalHeapTest();

void finalGeometryTest();

void finalAlgoTest();

#endif 


