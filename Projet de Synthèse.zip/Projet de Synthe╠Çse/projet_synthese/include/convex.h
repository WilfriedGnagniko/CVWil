#ifndef CONVEX_H_
#define CONVEX_H_

void printString(const char *param, const char *param2, const int algo, const int sort);

//void printInt(const int param);

#endif
