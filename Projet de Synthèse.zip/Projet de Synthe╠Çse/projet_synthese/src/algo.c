#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include "algo.h"
#include "geometry.h"
#include "list.h"
#include "tree.h"
#include "util.h"
#include "heap.h"
#include "sort.h"

/**
 * @brief Compare le points \p a et \p b.
 *
 * @param[in] a
 * @param[in] b
 * @return int si l'abscisse de \p a est plus petite que l'abscisse de \p b
 * renvoie 1, sinon renvoie 0. Dans le cas d'égalité, si l'ordonnée de \p a
 * est plus petite que l'ordonnée de \p b renvoie 1, sinon renvoie 0.
 */
static int smallerPoint(const void* a, const void* b) {
  if(X((Point*) a) == X((Point*) b)){
    if(Y((Point*) a) < Y((Point*) b))
      return 1;
    else
      return 0;
  }
  if (X((Point*) a) < X((Point*) b))
    return 1;
  else
    return 0;
}

/**
 * @brief Compare le points \p a et \p b.
 * 
 * @param[in] a 
 * @param[in] b 
 * @return int si l'abscisse de \p a est plus grande que l'abscisse de \p b
 * renvoie 1, sinon renvoie 0. Dans le cas d'égalité, si l'ordonnée de \p a
 * est plus grande que l'ordonnée de \p b renvoie 1, sinon renvoie 0.
 */
static int biggerPoint(const void* a, const void* b) {
  if(X((Point*) a) == X((Point*) b)){
    if(Y((Point*) a) > Y((Point*) b))
      return 1;
    else
      return 0;
  }
  if (X((Point*) a) > X((Point*) b))
    return 1;
  else
    return 0;
}


/**
 * @brief Réalise la lecture d'un ensemble des points à partir du fichier
 * \p filename.
 * Renvoie 2 paramètres : un tableau contenant les points du fichier
 * \p filename, le nombre \p N de ces points.
 *
 * @param[in] filename le nom du fichier qui contient les points d'entrée.
 * @param[out] N le nombre des points dans le fichier \p filename
 * (paramètre de sortie).
 * @return Point** le tableau avec les points du fichier \p filename.
 */
static Point** readInstance(const char* filename, int* N) {
  FILE * fichier = fopen(filename,"r");
  if(fichier == NULL) ShowMessage("erreur fopen",1);
  fscanf(fichier,"%d",N);
  Point ** Tab = (Point**)malloc((*N) * sizeof(Point *));
  long long int x,y;
  for(int i = 0; i < *N; i++){
    fscanf(fichier,"%lld",&x);
    fscanf(fichier,"%lld",&y);
    Point * point = newPoint(x,y);
    Tab[i] = point;
  }
  if(fclose(fichier) == -1)ShowMessage("erreur fclose",1);
  return Tab;

}

/**
 * @brief Réalise l'écriture de l'ensemble des points de la liste \p L
 * dans un fichier avec le nom \p filename.
 *
 * @param[in] filename le nom du fichier d'écriture.
 * @param[in] L la liste des points à écrire dans le fichier \p filename.
 */
static void writeSolution(const char* filename, List* L) {
	FILE *fd = fopen(filename, "w");
  if(fd == NULL) ShowMessage("Ouverture impossible", 1);
  int size = getListSize(L);
  fprintf(fd, "%d\n", size);
  LNode *E = Head(L);
  while(E != NULL && size != 0){
    long long int x = X((Point *)getLNodeData(E));
    long long int y = Y((Point *)getLNodeData(E));
    fprintf(fd, "%lld ", x);
    fprintf(fd, "%lld\n", y);
    E = Successor(E);
    size--;
  }
  if(fclose(fd) == -1) ShowMessage("Fermeture impossible", 1);
}

/**
 * @brief Transforme la liste des arcs \p dedges décrivant les arêtes
 * du polygone de l'enveloppe convexe à une liste des poins ordonnés
 * dans le sens horaire.
 * 
 * @param[in] edges la liste des arcs de l'enveloppe convexe
 * @return List* la liste des points de l'enveloppe convexe dans le sens
 * horaire
 */

static List * DedgesToClockwisePoints(List* dedges) {
  
  // Premiere partie
  LNode *Laux = Head(dedges);
  LNode *min = Successor(Head(dedges));
  while(Laux){
    //if((X(getOrigin((DEdge*)getLNodeData(Laux))) <= X(getOrigin((DEdge*)getLNodeData(min)))) && (Y(getOrigin((DEdge*)getLNodeData(Laux))) <= Y(getOrigin((DEdge*)getLNodeData(min)))))
    if(smallerPoint(getOrigin((void *)getLNodeData(Laux)), getOrigin((void *)getLNodeData(min))) == 1)
      min = Laux;
    Laux = Successor(Laux); 
  }

  ExchangeData(&(dedges->head->data), &(min->data));

  //Deuxieme partie

  LNode *T1 = Head(dedges);
  while(T1){
    LNode *T2 = Successor(Head(dedges));
    while(T2 && T1){
      Point * p1 = getDestination((DEdge*)getLNodeData(T1));
      Point * p2 = getOrigin((DEdge*)getLNodeData(T2));
      if((p1->x == p2->x) && (p1->y == p2->y)){
        ExchangeData(&(T1->succ->data), &(T2->data));
      }
      T2 = Successor(T2);
    } 
    T1 = Successor(T1);
  }

  //Troisieme partie
	List * L = newList(&viewPoint,&freePoint);
	listInsertLast(L, (void *)getOrigin(getTNodeData(Head(dedges))));
	LNode * E = Head(dedges);
  if(getListSize(dedges) == 1){
    Point *P1 = getOrigin(getTNodeData(E));
    listInsertLast(L, (void *)P1);
    Point *P2 = getDestination(getTNodeData(E));
    listInsertLast(L, (void *)P2);
    return L;
  }
  while(E != Tail(dedges)){
    Point *P = getDestination(getTNodeData(E));
    listInsertLast(L, (void *)P);
    E = Successor(E);
  }
  return L;
}

static void freeSetOfPoint(Point ** SetOfPoint,int *N){
	for(int i = 0;i < *N;i++){
		free((SetOfPoint[i]));
	}
	free(SetOfPoint);
  SetOfPoint = NULL;
}

static void viewSetOfPoint(Point ** setOfPoint, int *N){
  for(int i = 0;i < *N;i++){
    viewPoint((void *)(setOfPoint[i]));
    printf(";");
  }
  printf("\n");
}

void SlowConvexHull(const char* infilename, const char* outfilename) {
  int N;
  bool OK;
	Point ** setOfPoints = readInstance(infilename, &N);
  List * E = newList(&viewDEdge, &freeDEdge);
  for(int a = 0; a < N; a++){ // Recherche de couple
    for(int b = 0; b < N; b++){
      if(a == b) continue;
      OK = true; 
      for(int p = 0; p < N; p++){
        if(p == a || p == b) continue; 
        if(onLeft(setOfPoints[a], setOfPoints[b], setOfPoints[p]) == 1 || isIncluded(setOfPoints[a], setOfPoints[b], setOfPoints[p]) == 1)
          OK = false;  
      }  
      if(OK){
        DEdge *AB = newDEdge(setOfPoints[a], setOfPoints[b]);
        listInsertLast(E, (void*)AB);  
      }
    }
  }
   //viewList(E);
  List *L = DedgesToClockwisePoints(E); // Allocation sera faite
  
  //viewList(L);
 
  writeSolution(outfilename, L);

  //viewList(L);  si on veut afficher le résultat dans la console 

  freeList(L,0); // depend de writeSolution
  freeList(E,1); // Liste des arcs
  freeSetOfPoint(setOfPoints,&N); 
}

void ConvexHull(const char* infilename, const char* outfilename, int sortby) {
  int N;
  Point ** setOfPoints = readInstance(infilename, &N);
  
	if(sortby == 1) // Arbre
    CBTHeapSort((void**)setOfPoints, N, &biggerPoint, &viewPoint, &freePoint);
  else if(sortby == 2)// Tableau
    ArrayHeapSort((void**)setOfPoints, N, &biggerPoint, &viewPoint, &freePoint);
  else // Selection
    SelectionSort((void**)setOfPoints, N, &biggerPoint); 
  
  //enveloppe supérieur
  
  List * Lsup = newList(&viewPoint, &freePoint);
  for(int i = 0; i < 2; i++)
    listInsertLast(Lsup, (void*)setOfPoints[i]);

  for(int i = 2; i < N ; i++){
    listInsertLast(Lsup, (void*)setOfPoints[i]);
    while(getListSize(Lsup) > 2 && onLeft((Point*)getLNodeData(Predecessor(Predecessor(Tail(Lsup)))), (Point*)getLNodeData(Predecessor(Tail(Lsup))), (Point*)getLNodeData(Tail(Lsup))) == 1){
      listRemoveNode(Lsup, Predecessor(Tail(Lsup)));
    }
  }
  //enveloppe inferieur
  List * Linf = newList(&viewPoint, &freePoint);
  for(int j = N - 1; j > N - 3; j--)
    listInsertLast(Linf, (void*)setOfPoints[j]);

  for(int j = N - 3; j >= 0; j--){
    listInsertLast(Linf, (void*)setOfPoints[j]);
    while(getListSize(Linf) > 2 && onLeft((Point*)getLNodeData(Predecessor(Predecessor(Tail(Linf)))), (Point*)getLNodeData(Predecessor(Tail(Linf))), (Point*)getLNodeData(Tail(Linf))) == 1){
      listRemoveNode(Linf, Predecessor(Tail(Linf)));
    } 
  }
  void *lastSup = listRemoveLast(Lsup);
  void *lastInf = listRemoveLast(Linf);

  List *L = listConcatenate(Lsup, Linf);

  //viewList(L);  si on veut afficher le résultat dans la console
  
  writeSolution(outfilename, L);
  freeList(L,0); // depends de writeSolutions
  freeSetOfPoint(setOfPoints, &N);  
}

void RapidConvexHull(const char* infilename, const char* outfilename) {

 int N;
  Point ** setOfPoints = readInstance(infilename, &N);
  //Recherche du min
  Point * min = setOfPoints[0];
  for(int k = 1; k < N; k++){
    if(smallerPoint(setOfPoints[k], min) == 1)
      min = setOfPoints[k]; 
  }

  List * H = newList(&viewPoint, &freePoint);
  listInsertLast(H, (void*)min);
  Point * p1 = (Point*)getLNodeData(Head(H));
  Point * p2;
  int i = 1;
  do{
    if(setOfPoints[i] != (Point*)getLNodeData(Tail(H)))
      listInsertLast(H, (void*)setOfPoints[i]);
    for(int p = 0; p < N; p++){
      if(setOfPoints[p] == (Point*)getLNodeData(Tail(H)) || setOfPoints[p] == (Point*)getLNodeData(Predecessor(Tail(H)))) continue;
      Point *aux1 = (Point*)getLNodeData(Predecessor(Tail(H)));
      Point *aux2 = (Point*)getLNodeData(Tail(H));
      if(onLeft((Point*)getLNodeData(Predecessor(Tail(H))), (Point*)getLNodeData(Tail(H)), setOfPoints[p]) == 1 || isIncluded((Point*)getLNodeData(Predecessor(Tail(H))), (Point*)getLNodeData(Tail(H)), setOfPoints[p]) == 1){
        listRemoveLast(H);
        listInsertLast(H, (void*)setOfPoints[p]);
      }   
    } 
    i++;
    p2 = (Point*)getLNodeData(Tail(H));
  }while(p1 != p2);
  listRemoveLast(H);
  printf("\n");

   //viewList(H); si on veut afficher le résultat dans la console

  writeSolution(outfilename, H);
  freeList(H,0);
  freeSetOfPoint(setOfPoints,&N);
  
}