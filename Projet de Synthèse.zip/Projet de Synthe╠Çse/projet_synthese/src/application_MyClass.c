#include "application_MyClass.h"
 #include "util.h"
JNIEXPORT void JNICALL Java_application_MyClass_myPrint 
	(JNIEnv * env, jobject obj, jstring infilename, jstring outfilename, jint algo, jint sort) {
		const char *myInfile = (*env)->GetStringUTFChars(env, infilename, NULL); 		
		const char *myOutfile = (*env)->GetStringUTFChars(env, outfilename, NULL); 		
		
		printString(myInfile, myOutfile, algo, sort);
		//printInt(i);
}
