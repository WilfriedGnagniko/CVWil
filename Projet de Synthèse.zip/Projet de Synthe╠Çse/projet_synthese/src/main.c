#include <stdio.h>
#include <stdlib.h>

#include "util.h"
#include "list.h"
#include "tree.h"
#include "heap.h"
#include "sort.h"
#include "geometry.h"
#include "algo.h"
#include "test.h"




int main(int argc, char* argv[]){
	
	
	finalListTest();
	finalTreeTest();
	finalSortTest();
	finalHeapTest();
	finalGeometryTest();
	
	finalAlgoTest();

	return EXIT_SUCCESS;
}
