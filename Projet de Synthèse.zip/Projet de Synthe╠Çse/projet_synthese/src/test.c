#include "list.h"
#include "tree.h"
#include "heap.h"
#include "sort.h"
#include "geometry.h"
#include "algo.h"
#include "util.h"
#include "test.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

//CONSTANTE
#define NB_CASE_TEST_EXCEPT 10

int correct = 0, check = 0, error = NB_CASE_TEST_EXCEPT; 

static void init(){
	correct = 0;
	check = 0; 
	error = NB_CASE_TEST_EXCEPT; 
}

static void verify(const int valeurAttendue, const int valeurActuelle, char *msg, int *resultat){
	if(valeurAttendue == valeurActuelle){
		(*resultat)++;
		printf("PASSED : %s\n", msg);
	}else{
		(*resultat)--;
		printf("FAILED : %s\n", msg);
	}
	check++;
}
// LES TESTES SUR LES LISTES SONT SÉPARÉS EN GRANDES PARTIES : LNODES ET LIST
static int testNode(){

    int *ptra = (void*)malloc(sizeof(int));
	int *ptrb = (void*)malloc(sizeof(int));
	int *ptrc = (void*)malloc(sizeof(int));
	int *ptrd = (void*)malloc(sizeof(int));

	assert(ptra && ptrb && ptrc && ptrd);

	*ptra = 21;
	*ptrb = 34;
	*ptrc = 3;
	*ptrd = 5;
	
    LNode *na = newLNode((void*) ptra);
	int *aux = (int*)getLNodeData(na);
	verify(*ptra, *aux, "Test of newLNode", &correct);
    LNode *nb = newLNode((void*) ptrb);
	aux = (int*)getLNodeData(nb);
	verify(*ptrb, *aux, "Test of newLNode", &correct);

    setSuccessor(na,nb);
	setPredecessor(nb, na);
    if(Successor(na) == nb || Predecessor(nb) == na){
		correct++;
	}
   
    free(ptra);
    ptra = NULL;
    free(ptrb);
    ptrb = NULL;
    free(ptrc);
    ptrc = NULL;
    free(ptrd);
    ptrd = NULL;

    free(na);
    na = NULL;
    free(nb);
    nb = NULL;

    return correct;
    
}

static void testList(){

    List *L1 = newList(&viewInt,&freeInt);
	assert(L1);

    int *ptra = (void*)malloc(sizeof(int));
	int *ptrb = (void*)malloc(sizeof(int));
	int *ptrc = (void*)malloc(sizeof(int));
	int *ptrd = (void*)malloc(sizeof(int));
	int *ptre = (void*)malloc(sizeof(int));
	int *ptrf = (void*)malloc(sizeof(int));

	*ptra = 21;
	*ptrb = 34;
	*ptrc = 3;
	*ptrd = 5;
	*ptre = 19;
	*ptrf = 36;

    listInsertFirst(L1,ptra);
	verify(*(int*)getLNodeData(Head(L1)), *ptra, "Test of ListInsertFirst", &correct);
	
	listInsertLast(L1, ptrb);
	verify(2, getListSize(L1), "Test of the size after ListInsertFirst", &correct);
	verify(*(int*)getLNodeData(Tail(L1)), *ptrb, "Test of ListInsertLast", &correct);

	listRemoveFirst(L1);
	free(ptra);
	ptra = NULL;
	verify(*(int*)getLNodeData(Tail(L1)), *(int*)getLNodeData(Head(L1)), "Test of ListRemoveLast", &correct);

	listInsertAfter(L1, ptrc, Head(L1));
	verify(2, getListSize(L1), "Test of the size of ListInserAfter", &correct);

	List *L2 = newList(&viewInt,&freeInt);
	assert(L2);

	listInsertFirst(L2,ptrd);
	listInsertLast(L2,ptre);
	listInsertLast(L2,ptrf);
	L1 = listConcatenate(L1, L2);
	verify(5, getListSize(L1), "Test of the size of ListConcatenate", &correct);
	verify(*(int*)getLNodeData(Predecessor(Predecessor(Tail(L1)))), *(int*)getLNodeData(Successor(Successor(Head(L1)))), "Test of the middle data of ListConcatenate after inserting 5 data", &correct);

	freeList(L1, 1); // we should delete our data
}

void finalListTest(){
	testNode();
	testList();
	printf("\n[ LIST ==> Passed: %2.f %% : Checks: %d, Failure/Errors : %d ]\n", ((float)correct/NB_CASE_TEST_EXCEPT)*100, check, error - correct);
	init();
}

int finalTreeTest(){

  	CBTree * T = newCBTree(&viewInt, &freeInt);
  	int *a = calloc(1, sizeof(int));
  	*a = 3;
  	int *b = calloc(1, sizeof(int));
  	*b = 8;
  	int *c = calloc(1, sizeof(int));
  	*c = 6;
  	int *d = calloc(1, sizeof(int));
  	*d = 10;
  	int *e = calloc(1, sizeof(int));
  	*e = 20; 
	int *f = calloc(1, sizeof(int));
  	*f = 31;
  	int *g = calloc(1, sizeof(int));
  	*g = 74;
  	int *h = calloc(1, sizeof(int));
  	*h = 54; 

	
  	CBTreeInsert(T,a);
  	CBTreeInsert(T, b);
  	CBTreeInsert(T, c);
  	CBTreeInsert(T, d);
  	CBTreeInsert(T, e); 
	

	printf("La fonction devrait afficher l'odre préfixé qui est 3 8 10 20 6 \n");
  	viewCBTree(T, 0);	
  	printf("\n");

	printf("La fonction devrait afficher l'odre postfixé qui est 10 20 8 6 3 \n");
  	viewCBTree(T, 1);	
  	printf("\n");

	printf("La fonction devrait afficher l'odre infixé qui est 10 8 20 3 6  \n");
  	viewCBTree(T, 2);	
  	printf("\n");

	printf("La fonction devrait afficher l'odre infixé qui est 10 8 20 3 31 6  \n");
	CBTreeInsert(T, f);
	viewCBTree(T,2);

	
  	CBTreeInsert(T, g);
  	CBTreeInsert(T, h); 
	printf("\n");

	printf("La fonction devrait afficher l'odre infixé qui est 54 10 8 20 3 31 6 74  \n");
	viewCBTree(T, 2);	
	printf("\n");

	//Insertion et affichage OK

	
  	void *del_last = CBTreeRemove(T);
  	printf("Le dernier noeud a ete supprimé : ");
	viewInt(del_last);
	printf("\n");
	printf("Et la fonction devrait afficher l'ordre infixé qui est 10 8 20 3 31 6 74\n");
	viewCBTree(T, 2);	
	printf("\n");

	TNode * last = CBTreeGetLast(T);
	printf("Affichage de la derniere valeur qui est : 74\n");

	viewInt(getTNodeData(last));
	printf("\n");

	
	//Ajout des valeurs qui ne sont pas dans l'arbre afin de libérer toute la mémoire 
	
	CBTreeInsert(T,h);
	freeCBTree(T,1);

	
	return EXIT_SUCCESS;
}


static void afficheTab(void ** A,int N){
	printf("[");
	for(int i=0;i<N;i++){
		viewInt(A[i]);
		printf(",");
	}
	printf("]");
}

void finalSortTest(){

	const int N = 10;

	void **A = malloc(N*sizeof(void*));

	int *ptra = (void*)malloc(sizeof(int));
	*ptra = 21;

	int *ptrb = (void*)malloc(sizeof(int));
	*ptrb = 34;

	int *ptrc = (void*)malloc(sizeof(int));
	*ptrc = 3;

	int *ptrd = (void*)malloc(sizeof(int));
	*ptrd = 5;

	int *ptre = (void*)malloc(sizeof(int));
	*ptre = 19;

	int *ptrf = (void*)malloc(sizeof(int));
	*ptrf = 75;

	int *ptrg = (void*)malloc(sizeof(int));
	*ptrg = 100;

	int *ptrh = (void*)malloc(sizeof(int));
	*ptrh = 2;

	int *ptri = (void*)malloc(sizeof(int));
	*ptri = 13;

	int *ptrj = (void*)malloc(sizeof(int));
	*ptrj = 54;

	A[0] = ptra;
	A[1] = ptrb;
	A[2] = ptrc;
	A[3] = ptrd;
	A[4] = ptre;
	A[5] = ptrf;
	A[6] = ptrg;
	A[7] = ptrh;
	A[8] = ptri;
	A[9] = ptrj;
	

	printf("\nTableau original : \n");
	afficheTab(A,N);

	printf("\n\nTri par échange croissant");
	SelectionSort(A,N,&intGreaterThan);
	printf("\n");
	afficheTab(A,N);

	printf("\n\nTri par échange décroissant");
	SelectionSort(A,N,&intSmallerThan);
	printf("\n");
	afficheTab(A,N);
	
	printf("\n\nTri par tas implémenté par un tableau croissant: ");
	ArrayHeapSort(A,N,&intGreaterThan,&viewInt,&freeInt);
	printf("\n");
	afficheTab(A,N);

	printf("\n\nTri par tas implémenté par un tableau décroissant: ");
	ArrayHeapSort(A,N,&intSmallerThan,&viewInt,&freeInt);
	printf("\n");
	afficheTab(A,N);

	printf("\n\nTri par tas implémenté par un arbre croissant: ");
	CBTHeapSort(A,N,&intGreaterThan,&viewInt,&freeInt);
	printf("\n");
	afficheTab(A,N);

	printf("\n\nTri par tas implémenté par un arbre décroissant: ");
	CBTHeapSort(A,N,&intSmallerThan,&viewInt,&freeInt);
	printf("\n");
	afficheTab(A,N);


	printf("\n");

	List *L = newList(&viewInt, &freeInt);
	listInsertLast(L,(void *)ptra);
	listInsertLast(L,(void *)ptrb);
	listInsertLast(L,(void *)ptrc);
	listInsertLast(L,(void *)ptrd);
	listInsertLast(L,(void *)ptre);
	listInsertLast(L,(void *)ptrf);
	listInsertLast(L,(void *)ptrg);
	listInsertLast(L,(void *)ptrh);
	listInsertLast(L,(void *)ptri);
	listInsertLast(L,(void *)ptrj);
	freeList(L,1);
	free(A);
	
}



void finalHeapTest(){
	// TEST SUR LE HEAP
	
	void **A = (void**)calloc(5, sizeof(void*));
	int *a = calloc(1, sizeof(int));
	*a = 9;
	int *b = calloc(1, sizeof(int));
	*b = 8;
	int *c = calloc(1, sizeof(int));
	*c = 6;
	int *d = calloc(1, sizeof(int));
	*d = 0;
	int *e = calloc(1, sizeof(int));
	*e = 10;
	int *f = calloc(1, sizeof(int));
	*f = -2;
	
	// PARTIE SUR LE TABLEAU
	A[0] = a;
	A[1] = b;
	A[2] = c;
	A[3] = d;
	A[4] = e;
	printf("Array Data: \n");
	for(int j = 0; j < 5; j++){
		viewInt(A[j]);
		printf(" ");
	}
	printf("\nArrayToArrayHeap applied\n");
	ArrayHeap *AH = ArrayToArrayHeap(A, 5, &intSmallerThan, &viewInt, &freeInt);
	printf("\nupdateArrayHeapDownwards applied\n");
	viewArrayHeap(AH);
	void * min = ArrayHeapExtractMin(AH);
	printf("\nMin = ");
	viewInt(min);
	viewArrayHeap(AH); 
	void * min2 = ArrayHeapExtractMin(AH);
	printf("\nMin2 = ");
	viewInt(min2);
	viewArrayHeap(AH);
	freeArrayHeap(AH, 0);

	//PARTIE SUR L'ARBRE
	
	CBTHeap * H = newCBTHeap(&intSmallerThan, &viewInt, &freeInt);
	CBTHeapInsert(H, a);
	viewCBTHeap(H);
	printf("\n");
	CBTHeapInsert(H, b);
	viewCBTHeap(H);
	printf("\n");
	CBTHeapInsert(H, c);
	viewCBTHeap(H);
	printf("\n");
	CBTHeapInsert(H, d);
	viewCBTHeap(H);
	printf("\n");
	CBTHeapInsert(H, e);
	viewCBTHeap(H);
	printf("\n");
	CBTHeapInsert(H, f);
	viewCBTHeap(H);
	printf("\n");
	
	void *data1 = CBTHeapExtractMin(H);
	printf("\nLe min est : ");
	viewInt(data1);
	printf("\nL'arbre apres l'extration du min: \n");
	viewCBTHeap(H);
	void *data2 = CBTHeapExtractMin(H);
	printf("\nLe min est : ");
	viewInt(data2);
	printf("\nL'arbre apres l'extration du min: \n");
	viewCBTHeap(H);
	
	free(data1);
	free(data2);
	freeCBTHeap(H, 1);
	
}



void finalGeometryTest(){
	Point * origin = newPoint(0,0);
	Point * destination = newPoint(-5,5);
	Point * P = newPoint(1, 0);

	
	if(isIncluded(origin,destination,P) == 1)
		printf("est inclus\n");
	else
		printf("n'est pas inclus\n");

	if(collinear(origin, destination, P) == 1)
		printf("est collinéaire\n");
	else
		printf("n'est pas colinéaire\n");
	
	
	if(onLeft(origin,destination,P) == 1)
		printf("A Gauche\n");
	else
		printf("Pas a gauche\n");
	if(onRight(origin,destination,P) == 1)
		printf("A Droite\n");
	else
		printf("Pas a Droite\n");
	
	List *L1 = newList(&viewPoint,&freePoint);
	listInsertLast(L1,(void*)origin);
	listInsertLast(L1,(void*)destination);
	listInsertLast(L1,(void*)P);
	viewList(L1);
	freeList(L1,1);

	long long int x1 = 0, x2 = 7, y1 = 3, y2 = 9;

  	Point *x = newPoint(x1, x2);
 	Point *y = newPoint(y1, y2);
	List * L = newList(&viewPoint, &freePoint);
 	listInsertLast(L, (void*)x);
 	listInsertLast(L, (void*)y);
    viewList(L);
	freeList(L,1);
	printf("\n");
    
	
  
	Point * p1 = newPoint(2,1);
	Point * p2 = newPoint(2,-2);
	Point * p3 = newPoint(-1,-2);
	Point * p4 = newPoint(-1,1);

	DEdge * d1	 = newDEdge(p1,p2);
	DEdge * d2	 = newDEdge(p2,p3);
	DEdge * d3	 = newDEdge(p3,p4);
	DEdge * d4	 = newDEdge(p4,p1);

	List * L2 = newList(&viewDEdge,&freeDEdge);
	listInsertLast(L2,d1);
	listInsertLast(L2,d2);
	listInsertLast(L2,d3);
	listInsertLast(L2,d4);
	List * L3 = newList(&viewPoint,&freePoint);
	listInsertLast(L3,p1);
	listInsertLast(L3,p2);
	listInsertLast(L3,p3);
	listInsertLast(L3,p4);

	freeList(L2,1);
	freeList(L3,1);

}

void finalAlgoTest(){

	/*
	1 : tri par tas implémenté par un arbre (CBTHeapSort)
	2 : tri par tas implémenté par un tableau (ArrayHeapSort)
	3 : selection sort (SelectionSort)
	*/

	SlowConvexHull("data/testInD1", "data/testOutD1");
	ConvexHull("data/testInD1", "data/testOutD1", 1);
	ConvexHull("data/testInD1", "data/testOutD1", 2);
	ConvexHull("data/testInD1", "data/testOutD1", 3);
	RapidConvexHull("data/testInD1", "data/testOutD1");

	
}

 
