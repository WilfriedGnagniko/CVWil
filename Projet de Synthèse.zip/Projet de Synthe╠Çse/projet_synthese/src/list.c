#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "list.h"
#include "util.h"

/********************************************************************
 * LNode
 ********************************************************************/

LNode * newLNode(void* data) {
	LNode * E = (LNode *)malloc(sizeof(LNode));
	if(E == NULL){
	    ShowMessage("Mémoire pleine, impossible d'allouer un noeud dans newLNode", 1);
	 	return NULL;
	}
	 else{
	 	E->data = data;
		E->succ = NULL;
		E->pred = NULL;
	 	return E;
	}
}

void* getLNodeData(const LNode* node) {
	if(node == NULL){
		ShowMessage("le noeud passé en paramètre de getLNodeData est NULL", 1);
		return NULL;
	}
	else{
		return node->data;
	}
	
}

LNode* Successor(const LNode* node) {
	if(node == NULL){
		ShowMessage("le noeud passé en paramètre de Successor est NULL", 1);
		return NULL;
	}
	else{
		return node->succ;
	}
}

LNode* Predecessor(const LNode* node) {
	if(node == NULL){
		ShowMessage("le noeud passé en paramètre de Predecessor est NULL", 1);
		return NULL;
	}
	else{
		return node->pred;
	}
}

void setLNodeData(LNode* node, void* newData) {
	if(node == NULL){
		ShowMessage("le noeud passé en paramètre de setLNodeData est NULL", 1);
	}
	else{
		node->data = newData;
	}
}

void setSuccessor(LNode* node, LNode* newSucc) {
	if(node == NULL){
		ShowMessage("le noeud passé en paramètre de setSuccessor est NULL", 1);
	}
	else{
		node->succ = newSucc;
	}
}

void setPredecessor(LNode* node, LNode* newPred) {
	if(node == NULL){
		ShowMessage("le noeud passé en paramètre de setPredecessor est NULL", 1);
	}
	else{
		node->pred = newPred;
	}
}



/********************************************************************
 * List
 ********************************************************************/

List * newList(void (*viewData)(const void*), void (*freeData)(void*)) {
	List * L = (List *) malloc(sizeof(List));
	if(L == NULL){
	 	ShowMessage("Mémoire pleine, impossible d'allouer une liste dans newList", 1);
	 	return NULL;
	}
	else{
		// a tester avec les primitives de listes une fois écrites
		L->numelm = 0;
		L->head = NULL;
		L->tail = NULL;
		L->viewData = viewData;
		L->freeData = freeData;
	 	return L;
	}
}

int listIsEmpty(List* L) {
	if(L == NULL){
	 	ShowMessage("La liste L passé en paramètre de ListIsEmpty est NULL", 1);
	}
	else{
		if(L->numelm == 0)
			return 1;
		else
			return 0;
	}
	return 0;
}

int getListSize(const List* L) {
	if(L == NULL){
	 	ShowMessage("La liste L passé en paramètre de getListSize est NULL", 1);
	}
	else{
	 	return L->numelm;
	}
	return 0;
}

LNode* Head(const List* L) {
	if(L == NULL){
	 	ShowMessage("La liste L passé en paramètre de Head est NULL", 1);
	}
	else{
	 	return L->head;
	}
	return L->head;
}

LNode* Tail(const List* L) {
	if(L == NULL){
	 	ShowMessage("La liste L passé en paramètre de Tail est NULL", 1);
	}
	else{
	 	return L->tail;
	}
	return L->tail;
}

void increaseListSize(List* L) {
	if(L == NULL){
	 	ShowMessage("La liste L passé en paramètre de increaseListSize est NULL", 1);
	}
	else{
	 	L->numelm += 1 ;
	}
}

void decreaseListSize(List* L) {
	if(L == NULL){
	 	ShowMessage("La liste L passé en paramètre de dereaseListSize est NULL", 1);
	}
	else{
	 	L->numelm -= 1 ;
	}
}

void setListSize(List* L, int newSize) {
	if(L == NULL){
	 	ShowMessage("La liste L passé en paramètre de setListSize est NULL", 1);
	}
	else if (newSize < 0){
		ShowMessage("Une liste ne peut pas avoir un nombre négatif d'élément",1);
	}
	else{
	 	L->numelm = newSize;
	}
}

void resetListSize(List* L) {
	if(L == NULL){
	 	ShowMessage("La liste L passé en paramètre de resetListSize est NULL", 1);
	}
	else
		L->numelm = 0;
}

void setHead(List* L, LNode* newHead) {
	if(L == NULL){
	 	ShowMessage("La liste L passé en paramètre de setHead est NULL", 1);
	}

	else{
		L->head = newHead;
	}
}
void setTail(List* L, LNode* newTail) {
	if(L == NULL){
	 	ShowMessage("La liste L passé en paramètre de setTail est NULL", 1);
	}
	else{
		L->tail = newTail;
	}
}

void freeList(List * L, int deleteData) {	
	assert(deleteData == 0 || deleteData == 1);
	if(L == NULL){
	 	ShowMessage("La liste L passé en paramètre de freeList est NULL", 1);
	}
	while(! listIsEmpty(L)){
		LNode *E = Head(L);
		if(E != Tail(L))
			setHead(L,Successor(Head(L)));
		if(deleteData)
			L->freeData(getLNodeData(E));//suppression de la donnée (ici du point)
		free(E);
		E = NULL;	
		decreaseListSize(L);
	}
	free(L);
	L = NULL;
}

void viewList(const List * L) {
	//TODO erreur quand 1elt dans la liste 
	if(L == NULL)
		ShowMessage("La liste L passé en paramètre de viewList est NULL",1);
	if(listIsEmpty(L))
		printf("[]\n");
	else{
		LNode * iterator = Head(L);
		printf("[");
		for(int i=0;i<getListSize(L);i++){
			L->viewData(getLNodeData(iterator));// ici viewData = viewPoint
			if(Head(L) != Tail(L))
				iterator = Successor(iterator);
			printf(",");
		}
		printf("]\n");
		
	}
}

void listInsertFirst(List * L, void * data) {
	
	if(L == NULL){
	 	ShowMessage("La liste L passé en paramètre de listInsertFirst est NULL", 1);
	}
	LNode * node = newLNode(data);
	if(listIsEmpty(L)){
		setPredecessor(node, NULL);
		setSuccessor(node, NULL);
		setHead(L,node);
		setTail(L,node);
	}
	else{
		setPredecessor(Head(L),node);
		setSuccessor(node, Head(L));
		setPredecessor(node,NULL);
		setHead(L,node);
	}
	increaseListSize(L);
}	

void listInsertLast(List * L, void * data) {
	if(L == NULL){
	 	ShowMessage("La liste L passé en paramètre de listInsertLast est NULL", 1);
	}
	
	LNode * node = newLNode(data);
	if(listIsEmpty(L)){
		setPredecessor(node, NULL);
		setSuccessor(node, NULL);
		setHead(L,node);
		setTail(L,node);	
	}
	else{
		setSuccessor(Tail(L),node);
		setPredecessor(node,Tail(L));
		setSuccessor(node, NULL);
		setTail(L,node);
	}
	increaseListSize(L);
}

void listInsertAfter(List * L, void * data, LNode * ptrelm) {
	//TODO ajouter une fonction qui vérifie si ptrelm est dans la liste
	if(L == NULL || ptrelm == NULL){
	 	ShowMessage("Pointeur passé en paramètre de listInsertAfter NULL", 1);
	}
	else if(listIsEmpty(L))
		ShowMessage("liste vide dans listInsertAfter", 1);
	else if(ptrelm == Tail(L)){
		listInsertLast(L,data);
	}
	else{
		LNode * node = newLNode(data);
		setSuccessor(node,Successor(ptrelm));
		setSuccessor(ptrelm,node);
		setPredecessor(node,ptrelm);
		setPredecessor(Successor(node),node);
		increaseListSize(L);
	}

}

void* listRemoveFirst(List * L) {
	assert(Head(L));
	if(L == NULL){
		ShowMessage("Liste nulle dans listRemoveFirst",1);
	}
	if(listIsEmpty(L)){
		ShowMessage("Liste vide dans listRemoveFirst",1);
	}
	
	void * val_first = getLNodeData(Head(L));
	if(getListSize(L) == 1){
		free(Head(L));
		setHead(L,NULL);
		setTail(L,NULL);
	}
	else{
		LNode * E = (Head(L));
		setHead(L,Successor(Head(L)));
		free(E);
		E = NULL;	
	}
	decreaseListSize(L);
	return val_first;
}

void* listRemoveLast(List * L) {
	assert(Tail(L));
	if(L == NULL){
		ShowMessage("Liste nulle dans listRemoveLast",1);
	}
	if(listIsEmpty(L)){
		ShowMessage("Liste vide dans listRemoveLast",1);
	}
	
	void * val_last = getLNodeData(Tail(L));
	if(getListSize(L) == 1){
		free(Tail(L));
		setHead(L,NULL);
		setTail(L,NULL);
	}
	else{

		LNode* E = (Tail(L));
		setTail(L,Predecessor(Tail(L)));
		free(E);
		E = NULL;
		
	}
	decreaseListSize(L);
	return val_last;
}


void* listRemoveNode(List * L, LNode * node) {
	assert(Head(L) && Tail(L));
	if(L == NULL){
		ShowMessage("Liste nulle dans listRemoveNode",1);
		return NULL;
	}
	if(node == NULL){
		ShowMessage("Noeud nul dans listRemoveNode",1);
		return NULL;
	}
	if(node == Head(L)){
		listRemoveFirst(L);
	}
	else if(node == Tail(L)){
		listRemoveLast(L);
	}
	else{
		setSuccessor(Predecessor(node),Successor(node));
		setPredecessor(Successor(node),Predecessor(node));
		void *val = getLNodeData(node);
		free(node);
		decreaseListSize(L);
		return val;
	}
	return NULL;
}

List* listConcatenate(List* L1, List* L2) {
	if(L1 == NULL || L2 == NULL){
		ShowMessage("Liste vide dans la fonction listConcatenate",1);
	}
	if( ! listIsEmpty(L1)){
		setSuccessor(Tail(L1),Head(L2));
		setPredecessor(Head(L2),Tail(L1));
		setTail(L1,Tail(L2));
		setListSize(L1,getListSize(L1)+getListSize(L2));
		
		free(L2);
		L2 = NULL;
		return L1;
	}
	else{ // La liste L1 est vide
		freeList(L1,0);
		return L2;
	}
}