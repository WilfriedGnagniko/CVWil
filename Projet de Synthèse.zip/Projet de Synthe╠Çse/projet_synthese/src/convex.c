#include <stdlib.h>
#include <stdio.h>
#include "convex.h"
#include "algo.h"

void printString(const char *infilename, const char *outfilename, const int algo, const int sort) {

	if(infilename == NULL || infilename == ""){
		ShowMessage("infilename incorrect",1);
	}
	if(outfilename == NULL || outfilename == ""){
		ShowMessage("outfilename incorrect",1);
	}
	if(algo < 1 || algo > 3){
		ShowMessage("choisir un algo parmis les 3",1);
	}
	if(sort < 1 || sort > 3){
		ShowMessage("choisir un tri parmis les 3",1);
	}

	switch(algo){
	case 1 :
		SlowConvexHull(infilename, outfilename);
		break;
	case 2 :
		ConvexHull(infilename, outfilename,sort);
		break;
	default :
		RapidConvexHull(infilename, outfilename);
	}
}

}

/*void printInt(const int param) {
	printf("%d\n", param);
}*/
