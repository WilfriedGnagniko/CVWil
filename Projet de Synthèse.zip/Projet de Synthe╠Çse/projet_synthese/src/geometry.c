#include <stdio.h>
#include <stdlib.h>
#include "geometry.h"
#include "util.h"

Point* newPoint(long long int x, long long int y) {
	Point * P = (Point *)malloc(sizeof(Point));
	if(P == NULL){
		ShowMessage("Mémoire pleine, impossible d'allouer un point dans newPoint",1);
		return NULL;
	}
	P->x = x;
	P->y = y;
	return P;
}

long long int X(const Point* P) {
	if(P == NULL){
		ShowMessage("Le point passé en paramètre de X est null",1);
	}
	return P->x;
}

long long int Y(const Point* P) {
	if(P == NULL){
		ShowMessage("Le point passé en paramètre de Y est null",1);
	}
	return P->y;
}

void viewPoint(const void* P) {
	if(P == NULL){
		ShowMessage("Le point passé en paramètre de viewPoint est null",1);
	}
	printf("(%lld;%lld)",X((Point*) P),Y((Point*)P));
}



void freePoint(void* P) {
	if(P == NULL){
		ShowMessage("Le point passé en paramètre de freePoint est null",1);
	}
	free(P);
	P = NULL;
}

static int Expression(const Point* origin, const Point* destination, const Point* P){
	return ((X(destination)-X(origin))*(Y(P)-Y(origin))) - ((Y(destination)-Y(origin))*(X(P)-X(origin)));
}

int onRight(const Point* origin, const Point* destination, const Point* P) {
	if(P == NULL)
		ShowMessage("Le point passé en paramètre de onRight est null",1);
	if(origin == NULL)
		ShowMessage("Le point passé en paramètre de onRight est null",1);
	if(destination == NULL)
		ShowMessage("Le point passé en paramètre de onRight est null",1);

	if(Expression(origin,destination,P) < 0)
		return 1;
	else
		return 0;
}


int onLeft(const Point* origin, const Point* destination, const Point* P) {
	if(P == NULL)
		ShowMessage("Le point passé en paramètre de onLeft est null",1);
	if(origin == NULL)
		ShowMessage("Le point passé en paramètre de onLeft est null",1);
	if(destination == NULL)
		ShowMessage("Le point passé en paramètre de onLeft est null",1);
	if(Expression(origin,destination,P) > 0)
		return 1;
	else
		return 0;
}

int collinear(const Point* origin, const Point* destination, const Point* P) {
	if(P == NULL){
		ShowMessage("Le point passé en paramètre de collinear est null",1);
	}
	if(origin == NULL)
		ShowMessage("Le point passé en paramètre de collinear est null",1);
	if(destination == NULL)
		ShowMessage("Le point passé en paramètre de collinear est null",1);

	if(Expression(origin,destination,P) == 0) 
		return 1;
	else
		return 0;
}

int isIncluded(const Point* origin, const Point* destination, const Point* P) {
	if(P == NULL)
		ShowMessage("Le point passé en paramètre de isIncluded est null",1);
	if(origin == NULL)
		ShowMessage("Le point passé en paramètre de isIncluded est null",1);
	if(destination == NULL)
		ShowMessage("Le point passé en paramètre de isIncluded est null",1);
	if(collinear(origin,destination,P) == 1){
		if(X(origin) == X(destination)){ // Si le segment est verticale
			if((Y(origin) <= Y(P) && Y(P) <= Y(destination)) || (Y(destination) <= Y(P) && Y(P) <= Y(origin))){
				return 1;
			}else{
				return 0;
			}
		}else if((X(origin) <= X(P) && X(P) <= X(destination)) || (X(destination) <= X(P) && X(P) <= X(origin))){
			return 1;
		}else{
			return 0;
		}
	}else{
		return 0;
	} 		
}

DEdge* newDEdge(Point* origin, Point* destination) {
	DEdge * edge = (DEdge *)malloc(sizeof(DEdge));
	if(edge == NULL){
		ShowMessage("Mémoire pleine, impossible d'allouer un arc dans newDEdge",1);
	}
	edge->origin = origin;
	edge->destination = destination;
	return edge;
}

Point* getOrigin(const DEdge* DE) {
	if(DE == NULL){
		ShowMessage("arc null dans la fonction getOrigin",1);
	}
	return DE->origin;
}

Point* getDestination(const DEdge* DE) {
	if(DE == NULL){
		ShowMessage("arc null dans la fonction getDestination",1);
	}
	return DE->destination;
}

void viewDEdge(const void* DE) {
	if(DE == NULL){
		ShowMessage("arc null dans la fonction viewDEdge",1);
	}
	printf("Origin : ");
	viewPoint((void *)getOrigin(DE));
	printf(", ");
	printf("Destination : ");
	viewPoint((void *)getDestination(DE));
	printf("\n");

}

void freeDEdge(void* DE) {
	if(DE == NULL){
		ShowMessage("arc null dans la fonction freeDEdge",1);
	}
	free(DE);
	DE = NULL;
}

