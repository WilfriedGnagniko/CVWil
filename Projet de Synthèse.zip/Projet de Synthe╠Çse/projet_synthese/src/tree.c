#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include "tree.h"
#include "util.h"

/********************************************************************
 * TNode
 ********************************************************************/

TNode * newTNode(void* data) {
	TNode * node = (TNode*)calloc(1, sizeof(TNode));
  if(node == NULL)
    ShowMessage("Noeud non alloué", 1);
  node->data = data;
  return node;
}

void* getTNodeData(const TNode* node) {
  if(node == NULL)
    ShowMessage("node est null dans getTNodeData", 1);
  return node->data;
}

TNode* Left(const TNode* node) {
	if(node == NULL)
    ShowMessage("node est null dans Left", 1);
  return node->left;
}

TNode* Right(const TNode* node) {
	if(node == NULL)
    ShowMessage("node est null dans Right", 1);
  return node->right;
}

void setTNodeData(TNode* node, void* newData) {
	if(node == NULL)
    ShowMessage("node est null dans setTNodeData", 1);
  node->data = newData;
}

void setLeft(TNode* node, TNode* newLeft) {
	if(node == NULL)
    ShowMessage("node est null dans setLeft", 1);
  node->left = newLeft;
}

void setRight(TNode* node, TNode* newRight) {
	if(node == NULL)
    ShowMessage("node est null dans setRight", 1);
  node->right = newRight;
}

/********************************************************************
 * Complete Binary Tree
 ********************************************************************/

CBTree * newCBTree(void (*viewData)(const void*), void (*freeData)(void*)) {
	CBTree *tree = (CBTree*)calloc(1, sizeof(CBTree));
  if(tree == NULL)
    ShowMessage("L'arbre n'a pas pu etre crée.", 1);
  tree->numelm = 0;
  tree->freeData = freeData;
  tree->viewData = viewData;
  return tree;
}

int treeIsEmpty(CBTree* T) {
	if(T == NULL)
    ShowMessage("L'arbre est NULL dans treeIsEmpty", 1);
  if(T->numelm == 0)
    return 1;
  else
    return 0;

}

int getCBTreeSize(const CBTree* T) {
  if(T == NULL)
    ShowMessage("L'arbre est NULL dans getCBTreeSize", 1);  
  return T->numelm;
}

TNode* Root(const CBTree* T) {
	if(T == NULL)
    ShowMessage("L'arbre est NULL dans Root", 1);
  return T->root;
}

void increaseCBTreeSize(CBTree* T) {
	if(T == NULL)
    ShowMessage("L'arbre est NULL dans increaseCBTreeSize", 1);
  T->numelm = T->numelm + 1;
}

void decreaseCBTreeSize(CBTree* T) {
	if(T == NULL)
    ShowMessage("L'arbre est NULL dans decreaseCBTreeSize", 1);
  T->numelm = T->numelm - 1;
}

void resetCBTreeSize(CBTree* T) {
  if(T == NULL)
    ShowMessage("L'arbre est NULL dans resetCBTreeSize", 1);
	T->numelm = 0;
}

void setRoot(CBTree* T, TNode* newRoot) {
  if(T == NULL)
    ShowMessage("L'arbre est NULL dans setRoot", 1);
	T->root = newRoot;
}

/**
 * @brief Libère récursivement le sous-arbre raciné au nœud \p node.
 * Dans le cas où le pointeur de fonction \p freeData n'est pas NULL,
 * la mémoire de la donnée du nœud actuel est aussi libérée.
 * NB : procédure récursive.
 * 
 * @param[in] node 
 * @param[in] freeData 
 */
static void freeTNode(TNode* node, void (*freeData)(void*)) {
  if(node != NULL){
    if(freeData != NULL)
      freeData(getTNodeData(node));
    freeTNode(Left(node), freeData);
    freeTNode(Right(node), freeData);
    free(node);
    node = NULL;
  }
}

/**
 * NB : Utilisez la procédure récursive freeTNode.
 * Vous devez initialiser le paramètre freeData
 * par rapport à la valeur de deleteData.
 */
void freeCBTree(CBTree * T, int deleteData) {
  if(T == NULL)
    ShowMessage("L'arbre est NULL dans freeCBTree", 1);
	if(deleteData == 0){
    freeTNode(Root(T), NULL);
    free(T);
    T = NULL;
  }
  else{
    freeTNode(Root(T), T->freeData);
    free(T);
    T = NULL;
  }
}

/**
 * @brief Affiche les éléments de l'arbre raciné au nœud \p node
 * en réalisant un parcours préfixé.
 * Les données de chaque nœud sont afficher en utilisant le
 * pointer de fonction \p viewData.
 * 
 * @param[in] node 
 * @param[in] viewData 
 */
static void preorder(TNode *node, void (*viewData)(const void*)) {
	if(node != NULL){
    viewData(getTNodeData(node));
    printf(" ");
    preorder(Left(node), viewData);
    preorder(Right(node), viewData);
  }
}

/**
 * @brief Affiche les éléments de l'arbre raciné au nœud \p node
 * en réalisant un parcours infixé.
 * Les données de chaque nœud sont afficher en utilisant le
 * pointer de fonction \p viewData.
 * 
 * @param[in] node 
 * @param[in] viewData 
 */
static void inorder(TNode *node, void (*viewData)(const void*)) {
	if(node != NULL){
    inorder(Left(node), viewData);
    viewData(getTNodeData(node));
    printf(" ");
    inorder(Right(node), viewData);
  }
}

/**
 * @brief Affiche les éléments de l'arbre raciné au nœud \p node
 * en réalisant un parcours postfixé.
 * Les données de chaque nœud sont afficher en utilisant le
 * pointer de fonction \p viewData.
 * 
 * @param[in] node 
 * @param[in] viewData 
 */
static void postorder(TNode *node, void (*viewData)(const void*)) {
	if(node != NULL){
    postorder(Left(node), viewData);
    postorder(Right(node), viewData);
    viewData(getTNodeData(node));
    printf(" ");
  }
}

/**
 * NB : Utilisez les procédures récursives preorder, inorder et postorder.
 * Rappel : order = 0 (preorder), 1 (postorder), 2 (inorder)
 */
void viewCBTree(const CBTree* T, int order) {
  if(T == NULL)
    ShowMessage("L'arbre est NULL dans viewCBTree", 1);
	if(order == 0)
    preorder(Root(T), T->viewData);
  else if(order == 1)
    postorder(Root(T), T->viewData);
  else if(order == 2)
    inorder(Root(T), T->viewData);
  else
    ShowMessage("order invalide", 1); 
}

/**
 * @brief Insère récursivement un nouveau nœud de donnée \p data
 * dans l'arbre raciné au nœud \p node.
 * La position (par rapport à la racine \p node) où le nouveau nœud
 * va être insérer est indiquée par le paramètre \p position
 * (voir la figure ci-dessous pour la définition de la position).
 *  
 *          0
 *       /     \
 *      1       2
 *     / \     / \
 *    3   4   5   6
 *   / \
 *  7  ...
 * 
 * @param[in] node La racine de l'arbre actuel.
 * @param[in] position La position du nouveau élément
 * 						par rapport à la racine \p node.
 * @param[in] data La donnée à insérer.
 * @return TNode* Le nœud \p node mis à jour.
 */

static TNode* insertAfterLastTNode(TNode* node, int position, void* data) {
  if(node == NULL)
    return newTNode(data);
  else{
    int level = floor(log2(position)) + 1;
    int nbSheetMaxLevel = pow(2, level - 1); 
    int nbSheet = position  - nbSheetMaxLevel + 1 ;
    if(nbSheet <= nbSheetMaxLevel/2){ // il faut aller a gauche
      position = position - pow(2, level - 2);
      setLeft(node, insertAfterLastTNode(Left(node), position, data));
      return node;
    }else{ // Il faut aller a droite
      position = position - pow(2, level - 1);
      setRight(node, insertAfterLastTNode(Right(node), position, data));
      return node;
    }
  } 
}

/**
 * NB : Utilisez la procédure récursive insertAfterLastTNode
 * afin de lancer l'insertion.
 */
void CBTreeInsert(CBTree* T, void* data) {
  // ma position a insérer est le nombre d'element de l'arbre + 1
  // Facilite mon raisonnement
	int position = getCBTreeSize(T) + 1;
  T->root = insertAfterLastTNode(Root(T), position, data);
  increaseCBTreeSize(T);
}

/**
 * @brief Supprime récursivement le dernier nœud
 * de l'arbre raciné au nœud \p node.
 * La position (par rapport à la racine \p node) du nœud à supprimer
 * est indiquée par le paramètre \p position
 * (voir la figure ci-dessous pour la définition de la position).
 * La mémoire du dernier nœud est libérée mais pas la mémoire de sa donnée.
 *  
 *          0
 *       /     \
 *      1       2
 *     / \     / \
 *    3   4   5   6
 *   / \
 *  7  ...
 * 
 * @param[in] node La racine de l'arbre actuel.
 * @param[in] position La position de l'élément à supprimer
 *                         par rapport à la racine \p node.
 * @param[out] data La donnée du nœud supprimé (sortie).
 * @return TNode* Le nœud \p node mis à jour.
 */
static TNode* removeInstructions(TNode *node, void **data){ // a mettre dans le code de removeLastTNode
  *data = getTNodeData(node);
    free(node);
    node = NULL;
    return node;
}
static TNode* removeLastTNode(TNode* node, int position, void** data) { 
  if(node != NULL){
    if(Right(node) == NULL && Left(node) == NULL){
      return removeInstructions(node, data);
    }else{
      int level = floor(log2(position)) + 1;
      int nbSheetMaxLevel = pow(2, level - 1);
      int nbSheet = position - nbSheetMaxLevel + 1;
      if(nbSheet <= nbSheetMaxLevel/2){ // gauche
        position = position - pow(2, level - 2);
        setLeft(node, removeLastTNode(Left(node),position, data));
        return node;
      }else{ // droite
        position = position - pow(2, level - 1);
        setRight(node, removeLastTNode(Right(node), position, data));
        return node;
      }
    }
  }
}

/**
 * NB : Utilisez la procédure récursive removeLastTNode
 * afin de lancer la suppression.
 */
void* CBTreeRemove(CBTree* T){ // A revoir
	assert(Root(T));
  int position = getCBTreeSize(T) ;
  void *data;
  T->root = removeLastTNode(Root(T), position, &data); 
  decreaseCBTreeSize(T);
  return data;
}

/**
 * @brief Restitue récursivement le dernier nœud
 * de l'arbre raciné au nœud \p node.
 * La position (par rapport à la racine \p node) de ce dernier nœud
 * est indiquée par le paramètre \p position
 * (voir la figure ci-dessous pour la définition de la position).
 *  
 *          0
 *       /     \
 *      1       2
 *     / \     / \
 *    3   4   5   6
 *   / \
 *  7  ...
 * 
 * @param node La racine de l'arbre actuel.
 * @param position La position du dernier nœud par rapport à la racine \p node.
 * @return TNode* Le dernier nœud de l'arbre.
 */
static TNode* getLastTNode(TNode* node, int position) { // A revoir
	if(node != NULL){
    if(Right(node) == NULL && Left(node) == NULL){
      return node;
    }else{
      int level = floor(log2(position)) + 1;
      int nbSheetMaxLevel = pow(2, level - 1); 
      int nbSheet = position - nbSheetMaxLevel + 1 ;
      if(nbSheet <= nbSheetMaxLevel/2){ // gauche
        position = position - pow(2, level - 2);
        return getLastTNode(Left(node),position);
      }else{ // droite
        position = position - pow(2, level - 1);
        return getLastTNode(Right(node), position);  
      }
    }
  }
}

/**
 * NB : Utilisez la procédure récursive getLastTNode
 * afin de lancer la recherche.
 */
TNode* CBTreeGetLast(CBTree* T) {
  assert(Root(T));
  int position = getCBTreeSize(T);
  TNode *LastNode = getLastTNode(Root(T), position);
  return LastNode;
}

void CBTreeSwapData(TNode* node1, TNode* node2) {
  assert(node1 && node2);
  //ExchangeData(&getTNodeData(node1), &getTNodeData(node2));
  // au cas ou l'inst au dessus ne marche pas :), utiliser celle en dessous
   ExchangeData(&(node1->data), &(node1->data));
}