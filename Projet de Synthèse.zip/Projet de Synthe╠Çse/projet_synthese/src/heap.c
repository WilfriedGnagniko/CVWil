#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "tree.h"
#include "heap.h"
#include "util.h"

/**********************************************************************************
 * ARRAY HEAP
 **********************************************************************************/

int getAHMaxSize(const ArrayHeap* AH) {
	assert(AH != NULL);
  return AH->MAX;
}

int getAHActualSize(const ArrayHeap* AH) {
	assert(AH != NULL);
  return AH->N;
}

void* getAHNodeAt(const ArrayHeap* AH, int pos) {
	assert(AH != NULL && pos < AH->N);
  return AH->A[pos];
}

void decreaseAHActualSize(ArrayHeap* AH) {
	assert(AH != NULL && AH->N > 1);
  AH->N = getAHActualSize(AH) - 1;
}

void setAHNodeAt(ArrayHeap* AH, int position, void* newData) {
	assert(AH != NULL && position < getAHActualSize(AH));
  AH->A[position] = newData;
}

/**
 * @brief Corrige la position de l'élément de la position \p pos
 * du tas \p AH en le comparant avec ses fils et en l'échangeant avec
 * le fils de la plus grande priorité si nécessaire.
 *
 * Procédure récursive.
 * 
 * @param[in] AH 
 * @param[in] pos L'indice de la valeur en mouvement vers le bas.
 */
static void updateArrayHeapDownwards(ArrayHeap* AH, int pos) {
	if(pos < getAHActualSize(AH)/2){
    int leftSon = 2 * pos + 1, rightSon = leftSon + 1, minSon;
    if(rightSon < getAHActualSize(AH)){
      int res1 = (AH->preceed)(getAHNodeAt(AH, leftSon), getAHNodeAt(AH, rightSon));
      minSon = (res1 == 1) ? leftSon : rightSon;
    }else{
      minSon = leftSon;
    }
    int res2 = (AH->preceed)(getAHNodeAt(AH, minSon), getAHNodeAt(AH, pos));
    if(res2 == 1){
      ExchangeData(AH->A + minSon, AH->A + pos);
      updateArrayHeapDownwards(AH, minSon);
    }
  }
}

ArrayHeap* ArrayToArrayHeap(void** A, int N,
					int (*preceed)(const void*, const void*),
					void (*viewHeapData)(const void*),
					void (*freeHeapData)(void*)) {
	ArrayHeap *AH = (ArrayHeap *)calloc(1, sizeof(ArrayHeap));
  if(AH == NULL)
    ShowMessage("Erreur dans ArrayToArrayHeap", 1);
  AH->preceed = preceed;
  AH->viewHeapData = viewHeapData;
  AH->freeHeapData = freeHeapData;
  AH->N = N;
  AH->A = A;
  for(int i = getAHActualSize(AH)/2 - 1; i >= 0; i--)
    updateArrayHeapDownwards(AH, i);
  return AH;
}

void viewArrayHeap(const ArrayHeap* AH) {
  	if(AH == NULL)
    	ShowMessage("Erreur dans viewArrayHeap", 1);
    printf("\n-------------------\n");
    printf("| Array Heap Data | \n");
    printf("-------------------\n\n");
    for(int i = 0; i < getAHActualSize(AH); i++){
        (AH->viewHeapData)(AH->A[i]);
        printf(" "); 
    }   
}

void freeArrayHeap(ArrayHeap* AH, int deletenode) {
	  if(deletenode != 0){
    	for(int i = 0; i < getAHActualSize(AH); i++)
        (AH->freeHeapData)(AH->A[i]);
    }
    free(AH->A);
    free(AH);
    AH = NULL;
}

void* ArrayHeapExtractMin(ArrayHeap* AH) {
	assert(getAHActualSize(AH) > 0);
	void *minSon = AH->A[0];
  AH->A[0] = AH->A[AH->N - 1];
  AH->N = AH->N - 1;
  updateArrayHeapDownwards(AH, 0);
  return minSon;
}

/**********************************************************************************
 * COMPLETE BINARY TREE HEAP
 **********************************************************************************/

CBTHeap* newCBTHeap(int (*preceed)(const void*, const void*),
					void (*viewHeapData)(const void*),
					void (*freeHeapData)(void*)) {
	CBTHeap *H = (CBTHeap*)calloc(1, sizeof(CBTHeap)); 
  H->preceed = preceed;
  H->viewHeapData = viewHeapData;
  H->freeHeapData = freeHeapData;
  H->T = newCBTree(viewHeapData, freeHeapData);
  return H;
}

CBTree* getCBTree(const CBTHeap* H) {
	if(H == NULL)
    ShowMessage("Erreur dans getBCTree", 1);
  return H->T;
}

/**
 * @brief Corrige la position du nœud à la position \p pos
 * de l'arbre raciné à \p node en le comparant avec son père
 * et en l'échangeant avec lui si nécessaire.
 * Le pointeur de fonction \p preceed est utilisé pour la comparaison.
 *
 * Procédure récursive. En descendant, on cherche le premier nœud
 * à corriger qui se trouve dans la position \p pos (de la même façon
 * que dans insertAfterLastTNode). En remontant, on corrige en échangeant
 * avec le père, si besoin.
 * 
 * @param[in] node 
 * @param[in] position 
 * @param[in] preceed 
 */

static void ExchangeHeapInstruction(TNode *node, int (*preceed)(const void*, const void*)){
    if(Right(node) == NULL && Left(node) != NULL){
      if((preceed)(getTNodeData(Left(node)), getTNodeData(node)) == 1){
        ExchangeData(&(node->left->data), &(node->data));
      }
    }else if(Right(node) != NULL && Left(node) != NULL){
      if((preceed)(getTNodeData(Left(node)), getTNodeData(Right(node))) == 1){ // Fils gauche a la priorité
        if((preceed)(getTNodeData(Left(node)), getTNodeData(node)) == 1)
            ExchangeData(&(node->left->data), &(node->data));
      }else {// Fils droit a la priorité
        if((preceed)(getTNodeData(Right(node)), getTNodeData(node)) == 1)
          ExchangeData(&(node->right->data), &(node->data));
      }
  }  
}

static void updateCBTHeapUpwards(TNode* node, int pos, int (*preceed)(const void*, const void*)) {
  if(node != NULL){
    if((Right(node) == NULL && Left(node) != NULL) || (Right(node) != NULL && Left(node)!= NULL)){
      int level = floor(log2(pos)) + 1;
      int nbSheetMaxLevel = pow(2, level - 1);
      int nbSheet = pos - nbSheetMaxLevel + 1;
      if(nbSheet <= nbSheetMaxLevel/2){ // Gauche
        pos = pos - pow(2, level - 2);
        updateCBTHeapUpwards(Left(node), pos, preceed);
        ExchangeHeapInstruction(node, preceed);
      }else { // Droite
        pos = pos - pow(2, level - 1);
        updateCBTHeapUpwards(Right(node), pos, preceed);
        ExchangeHeapInstruction(node, preceed);  
      } 
    }
  }
}

void CBTHeapInsert(CBTHeap *H, void* data) {
	CBTreeInsert(H->T, data);
  int position = getCBTreeSize(getCBTree(H));
  updateCBTHeapUpwards(Root(getCBTree(H)), position, H->preceed);
} 

/**
 * @brief Corrige la position du nœud \p node en le comparant avec ses fils
 * et en l'échangeant avec le fils de la plus grande priorité si nécessaire.
 * Le pointeur de fonction \p preceed est utilisé pour la comparaison.
 *
 * Procédure récursive.
 *
 * NB: Le sous-arbre avec racine \p node ne peut pas être vide.
 * 
 * @param[in] node 
 * @param[in] preceed 
 */

static void updateCBTHeapDownwards(TNode* node, int (*preceed)(const void*, const void*)) {
	//assert(node);
  if(node != NULL){
    if(Right(node) == NULL && Left(node) != NULL){
      if((preceed)(getTNodeData(Left(node)), getTNodeData(node)) == 1)
        ExchangeData(&(node->left->data), &(node->data));
    }else if(Right(node) != NULL && Left(node) != NULL){
      if((preceed)(getTNodeData(Left(node)), getTNodeData(Right(node))) == 1){
        // Fils Gauche a la prorité entre les deux fils
        if((preceed)(getTNodeData(Left(node)), getTNodeData(node)) == 1){
          // Fils Gauche a la priorité sur son pere
          ExchangeData(&(node->left->data), &(node->data));
          updateCBTHeapDownwards(Left(node), preceed);
        }
      }else{// Fils Droit a la priorité entre les deux fils
        if((preceed)(getTNodeData(Right(node)), getTNodeData(node)) == 1){
          ExchangeData(&(node->right->data), &(node->data));
          updateCBTHeapDownwards(Right(node), preceed);
        }
      }
    }
  }
}

void * CBTHeapExtractMin(CBTHeap *H) {
	//assert(Root(getCBTree(H)));
  //void setTNodeData(TNode* node, void* newData)
  void *min = getTNodeData(Root(getCBTree(H)));
	void *Ldata = CBTreeRemove(getCBTree(H));
  if(Root(getCBTree(H)) != NULL){
    setTNodeData(Root(getCBTree(H)), Ldata);
    updateCBTHeapDownwards(Root(getCBTree(H)), H->preceed);
  }
  return min;
}

void viewCBTHeap(const CBTHeap * H) {
	if(H == NULL && getCBTree(H) == NULL)
    ShowMessage("Erreur dans le viewCBTHeap", 1); // au cas ou on veut demander a l'utilisateur le mode d'affichage
  /*
  unsigned int i;
  do{
    printf("\n0(preorder), 1(postorder), 2(inorder): \n");
    scanf("%u", &i);
  }while(i > 2);
  */
  viewCBTree(getCBTree(H), 2);
}


void freeCBTHeap(CBTHeap* H, int deletenode) {
  if(H == NULL)
    ShowMessage("Erreur dans le freeCBTHeap, H est NULL", 1);
	freeCBTree(getCBTree(H), deletenode);
  free(H);
  H = NULL;
}
