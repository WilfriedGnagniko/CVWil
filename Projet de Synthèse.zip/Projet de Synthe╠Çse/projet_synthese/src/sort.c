#include <stdlib.h>
#include "tree.h"
#include "heap.h"
#include "sort.h"
#include "util.h"


void ArrayHeapSort(void** A, int N,
					int (*preceed)(const void*, const void*),
					void (*viewHeapData)(const void*),
					void (*freeHeapData)(void*)) {
	if(N==1);
	else if(N>1){
		ArrayHeap * AH = ArrayToArrayHeap(A,N,preceed,viewHeapData,freeHeapData);		
		for(int i = N-1;i>0;i--){
			A[i] = ArrayHeapExtractMin(AH);
		}
		free(AH);
	}
	else{
		ShowMessage("Probleme avec la taille du tableau a trier",1);
	}
}


void CBTHeapSort(void** A, int N,
					int (*preceed)(const void*, const void*),
					void (*viewHeapData)(const void*),
					void (*freeHeapData)(void*)) {
	if(N == 1);
	else if(N > 1){
		CBTHeap * H = newCBTHeap(preceed,viewHeapData,freeHeapData);
		for(int i = 0;i<N;i++){
			CBTHeapInsert(H,A[i]);
		}
		for(int i = N-1;i>=0;i--){
			A[i] = CBTHeapExtractMin(H);
		}
		freeCBTHeap(H,1);
	}
	else{
		ShowMessage("Probleme avec la taille du tableau a trier",1);
	}
	
}

void SelectionSort(void** A, int N, int (*preceed)(const void*, const void*)) {
	if(N == 1);
	else if(N > 1){
		int i, j, min;
		for(i = 0; i <= N-2; i++){
			min = i;
			for(j = i + 1; j <= N-1; j++){
				if(preceed(A[min],A[j]) == 1) // en fonction de preceed
					min = j;
			}
			if(min != i)
				ExchangeData(A+i, A+min);
		}
	}
	else{
		ShowMessage("Probleme avec la taille du tableau a trier",1);
	}
}
