package application;

public class MyClass {

	public native void myPrint(String infilename, String outfilename, int algo, int sort);

	public static void main(String[] args) {
		new MyClass().myPrint("../data/testInD1", "../data/testOutD1", 1, 1);
	}

	static {
		System.loadLibrary("mylibrary");
	}
}
